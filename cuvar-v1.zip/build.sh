#!/usr/bin/env bash
# Pravi APK na GitHub Actions i objavljuje ga kao Release.
set -euo pipefail
cd "$(dirname "$0")"

export JAVA_HOME="${JAVA_HOME_17_X64:-${JAVA_HOME_21_X64:-${JAVA_HOME:-}}}"
export PATH="$JAVA_HOME/bin:$PATH"
java -version

export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
echo "Android SDK: $ANDROID_HOME"

# Za svaki slucaj: potrebni delovi Android SDK-a (ako vec postoje, ovo ne radi nista).
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKM" ]; then
  (yes 2>/dev/null | "$SDKM" "platforms;android-34" "build-tools;34.0.0" >/dev/null 2>&1) || true
fi

GRADLE_VERSION=8.9
curl -fsSL --retry 3 -o /tmp/gradle.zip "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
unzip -q -o /tmp/gradle.zip -d /tmp
"/tmp/gradle-${GRADLE_VERSION}/bin/gradle" --no-daemon --stacktrace assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
ls -la "$APK"
cp "$APK" /tmp/cuvar.apk

TAG="v${RUN_NO:-1}"
echo "Objavljujem $TAG"
gh release delete "$TAG" --repo "$REPO" --yes --cleanup-tag >/dev/null 2>&1 || true
if gh release create "$TAG" /tmp/cuvar.apk --repo "$REPO" --title "Cuvar $TAG" --notes "Preuzmi cuvar.apk ispod (Assets) i instaliraj ga na telefon."; then
  echo "GOTOVO: APK je u Releases."
else
  echo "Release nije uspeo, stavljam APK direktno u repozitorijum."
  cd ..
  cp /tmp/cuvar.apk ./cuvar.apk
  git config user.name "github-actions"
  git config user.email "github-actions@users.noreply.github.com"
  git add cuvar.apk
  git commit -m "APK $TAG"
  git push
  echo "GOTOVO: cuvar.apk je u repozitorijumu."
fi
